<?php
session_start();
$koneksi = new mysqli("localhost","root","","db_perpustakaan");

// LOGIN
if (isset($_POST['login'])) {
    $u = $_POST['username'];
    $p = md5($_POST['password']);
    $cek = $koneksi->query("SELECT * FROM pengguna WHERE username='$u' AND password='$p'");
    if ($cek->num_rows > 0) {
        $_SESSION['admin'] = $u;
        header("Location: ?page=dashboard");
    } else {
        echo "<script>alert('Login gagal!');</script>";
    }
}
if (isset($_GET['logout'])) {
    session_destroy();
    header("Location: ?");
}

// --- CRUD ANGGOTA
if (isset($_POST['daftar_anggota'])) {
    $koneksi->query("INSERT INTO anggota(nama, alamat, no_hp) VALUES('{$_POST['nama']}', '{$_POST['alamat']}', '{$_POST['no_hp']}')");
    header("Location: ?page=anggota");
}
if (isset($_POST['edit_anggota'])) {
    $koneksi->query("UPDATE anggota SET nama='{$_POST['nama']}', alamat='{$_POST['alamat']}', no_hp='{$_POST['no_hp']}' WHERE id_anggota='{$_POST['id']}'");
    header("Location: ?page=anggota");
}
if (isset($_GET['hapus_anggota'])) {
    $koneksi->query("DELETE FROM anggota WHERE id_anggota='{$_GET['hapus_anggota']}'");
    header("Location: ?page=anggota");
}

// --- CRUD BUKU
if (isset($_POST['tambah_buku'])) {
    $koneksi->query("INSERT INTO buku(judul, penulis, tahun, kategori, stok)
        VALUES('{$_POST['judul']}','{$_POST['penulis']}','{$_POST['tahun']}','{$_POST['kategori']}','{$_POST['stok']}')");
    header("Location: ?page=buku");
}
if (isset($_POST['edit_buku'])) {
    $koneksi->query("UPDATE buku SET judul='{$_POST['judul']}', penulis='{$_POST['penulis']}', tahun='{$_POST['tahun']}', kategori='{$_POST['kategori']}', stok='{$_POST['stok']}' WHERE id_buku='{$_POST['id']}'");
    header("Location: ?page=buku");
}
if (isset($_GET['hapus_buku'])) {
    $koneksi->query("DELETE FROM buku WHERE id_buku='{$_GET['hapus_buku']}'");
    header("Location: ?page=buku");
}

// --- TRANSAKSI
if (isset($_POST['tambah_transaksi'])) {
    $id_buku = $_POST['id_buku'];
    $stok = $koneksi->query("SELECT stok FROM buku WHERE id_buku='$id_buku'")->fetch_assoc()['stok'];
    if ($stok > 0) {
        // kurangi stok 1
        $koneksi->query("UPDATE buku SET stok = stok - 1 WHERE id_buku='$id_buku'");
        $koneksi->query("INSERT INTO transaksi(id_buku, id_anggota, tanggal_pinjam)
            VALUES('$id_buku','{$_POST['id_anggota']}','{$_POST['tanggal_pinjam']}')");
        header("Location: ?page=transaksi");
    } else {
        echo "<script>alert('Stok buku habis!'); window.location='?page=transaksi';</script>";
    }
}

if (isset($_POST['pengembalian'])) {
    $id_transaksi = $_POST['id'];
    $tgl = date('Y-m-d');
    $koneksi->query("UPDATE transaksi SET tanggal_kembali='$tgl' WHERE id_transaksi='$id_transaksi'");

    // ambil id_buku dari transaksi untuk tambah stok
    $getBuku = $koneksi->query("SELECT id_buku FROM transaksi WHERE id_transaksi='$id_transaksi'")->fetch_assoc();
    $koneksi->query("UPDATE buku SET stok = stok + 1 WHERE id_buku='{$getBuku['id_buku']}'");

    header("Location: ?page=transaksi");
}

// Fungsi Denda
function hitung_denda($tgl_pinjam, $tgl_kembali) {
    $jatuh_tempo = date_create($tgl_pinjam)->modify('+7 days');
    $akhir = $tgl_kembali ? date_create($tgl_kembali) : date_create(date('Y-m-d'));
    $diff = date_diff($jatuh_tempo, $akhir)->days;
    return ($akhir > $jatuh_tempo) ? $diff * 1000 : 0;
}
?>
<!DOCTYPE html>
<html>
    <head>
        <style>
    body{font-family:sans-serif;background:#eef9ff;margin:0}.container{width:90%;max-width:1000px;margin:auto;padding:20px}
    nav{background:#00bcd4;padding:10px}
    nav a{color:#fff;margin:0 10px;text-decoration:none;font-weight:bold}.card{background:#fff;padding:20px;margin-top:20px;border-radius:8px;box-shadow:0 0 10px #ccc}
    input,select{width:100%;padding:10px;margin:5px 0}
    button{background:#00bcd4;color:#fff;border:none;padding:10px 20px;cursor:pointer}
    table{width:100%;border-collapse:collapse;margin-top:15px}
    th,td{border:1px solid #ddd;padding:10px}
    th{background:#f0f0f0}
        </style>
    </head>
<body>
    <div class="container">
<?php if (!isset($_SESSION['admin'])): ?>
    <div class="card"><h2>Login Admin</h2><form method="post">
    <input name="username" placeholder="Username"><input type="password" name="password" placeholder="Password">
    <button name="login">Login</button></form></div>
<?php else: ?>
<nav>
    <a href="?page=dashboard">Dashboard</a>
    <a href="?page=anggota">Anggota</a>
    <a href="?page=buku">Buku</a>
    <a href="?page=transaksi">Transaksi</a>
    <a href="?logout">Logout</a>
</nav>
<?php $page = $_GET['page'] ?? 'dashboard'; switch($page):
case 'anggota':
  if (isset($_GET['edit'])) $edit = $koneksi->query("SELECT * FROM anggota WHERE id_anggota='{$_GET['edit']}'")->fetch_assoc();
?>
<div class="card"><h3><?= isset($edit) ? 'Edit' : 'Formulir' ?> Pendaftaran Anggota</h3><form method="post">
    <input type="hidden" name="id" value="<?= $edit['id_anggota'] ?? '' ?>">
    <input name="nama" placeholder="Nama" value="<?= $edit['nama'] ?? '' ?>" required>
    <input name="alamat" placeholder="Alamat" value="<?= $edit['alamat'] ?? '' ?>">
    <input name="no_hp" placeholder="No HP" value="<?= $edit['no_hp'] ?? '' ?>">
    <button name="<?= isset($edit) ? 'edit_anggota' : 'daftar_anggota' ?>"><?= isset($edit) ? 'Update' : 'Daftar' ?></button>
    </form>
</div>
<div class="card"><h3>Data Anggota</h3><table><tr><th>Nama</th><th>Alamat</th><th>No HP</th><th>Aksi</th></tr>
    <?php $q = $koneksi->query("SELECT * FROM anggota"); while ($d = $q->fetch_assoc()): ?>
    <tr>
        <td><?= $d['nama'] ?></td><td><?= $d['alamat'] ?></td><td><?= $d['no_hp'] ?></td>
        <td><a href="?page=anggota&edit=<?= $d['id_anggota'] ?>">Edit</a> | <a href="?page=anggota&hapus_anggota=<?= $d['id_anggota'] ?>" onclick="return confirm('Hapus?')">Hapus</a></td></tr>
    <?php endwhile; ?></table></div><?php break;

case 'buku':
  if (isset($_GET['edit'])) $bukuEdit = $koneksi->query("SELECT * FROM buku WHERE id_buku='{$_GET['edit']}'")->fetch_assoc();
?>
<div class="card"><h3>Tambah / Edit Buku</h3><form method="post">
    <input type="hidden" name="id" value="<?= $bukuEdit['id_buku'] ?? '' ?>">
    <input name="judul" placeholder="Judul Buku" required value="<?= $bukuEdit['judul'] ?? '' ?>">
    <input name="penulis" placeholder="Penulis" value="<?= $bukuEdit['penulis'] ?? '' ?>">
    <input type="number" name="tahun" placeholder="Tahun Terbit" value="<?= $bukuEdit['tahun'] ?? '' ?>">
    <input name="kategori" placeholder="Kategori / Rak" value="<?= $bukuEdit['kategori'] ?? '' ?>">
    <input type="number" name="stok" placeholder="Stok Buku" value="<?= $bukuEdit['stok'] ?? '' ?>">
    <button name="<?= isset($bukuEdit) ? 'edit_buku' : 'tambah_buku' ?>"><?= isset($bukuEdit) ? 'Update Buku' : 'Simpan Buku' ?></button>
    </form>
</div>
<div class="card"><h3>Data Buku</h3><table><tr><th>Judul</th><th>Penulis</th><th>Tahun</th><th>Kategori</th><th>Stok</th><th>Aksi</th></tr>
    <?php $res = $koneksi->query("SELECT * FROM buku"); while ($b = $res->fetch_assoc()): ?>
    <tr>
        <td><?= $b['judul'] ?></td>
        <td><?= $b['penulis'] ?></td>
        <td><?= $b['tahun'] ?></td>
        <td><?= $b['kategori'] ?></td>
        <td><?= $b['stok'] ?></td>
        <td><a href="?page=buku&edit=<?= $b['id_buku'] ?>">Edit</a> | <a href="?page=buku&hapus_buku=<?= $b['id_buku'] ?>" onclick="return confirm('Hapus?')">Hapus</a></td></tr>
    <?php endwhile; ?></table></div><?php break;

case 'transaksi': ?>
<div class="card"><h3>Peminjaman Baru</h3><form method="post">
    <select name="id_buku" required><option value="">Pilih Buku</option><?php foreach($koneksi->query("SELECT * FROM buku") as $b): ?><option value="<?=$b['id_buku']?>"><?= $b['judul'] ?></option><?php endforeach; ?></select>
    <select name="id_anggota" required><option value="">Pilih Anggota</option><?php foreach($koneksi->query("SELECT * FROM anggota") as $a): ?><option value="<?=$a['id_anggota']?>"><?= $a['nama'] ?></option><?php endforeach; ?></select>
    <input type="date" name="tanggal_pinjam" required><button name="tambah_transaksi">Pinjam</button></form></div>
    <div class="card"><h3>Data Transaksi</h3><table><tr><th>Buku</th><th>Anggota</th><th>Pinjam</th><th>Kembali</th><th>Status</th><th>Denda</th><th>Aksi</th></tr>
    <?php $res = $koneksi->query("SELECT t.*, b.judul, a.nama FROM transaksi t JOIN buku b ON t.id_buku=b.id_buku JOIN anggota a ON t.id_anggota=a.id_anggota"); while($tr = $res->fetch_assoc()): $denda = hitung_denda($tr['tanggal_pinjam'], $tr['tanggal_kembali']); ?>
        <tr><td><?=$tr['judul']?></td>
        <td><?=$tr['nama']?></td>
        <td><?=$tr['tanggal_pinjam']?></td>
        <td><?=$tr['tanggal_kembali'] ?: '-'?></td>
        <td><?= $tr['tanggal_kembali'] ? 'Selesai' : 'Aktif' ?></td>
        <td>Rp <?= number_format($denda,0,',','.') ?></td>
        <td><?php if(!$tr['tanggal_kembali']): ?><form method="post" style="display:inline"><input type="hidden" name="id" value="<?=$tr['id_transaksi']?>"><button name="pengembalian">Kembalikan</button></form><?php endif; ?></td></tr>
    <?php endwhile; ?></table></div><?php break;

default: echo '<div class="card"><h2>Selamat Datang, '.htmlspecialchars($_SESSION['admin']).'</h2></div>'; endswitch; ?>
<?php endif; ?>
</div>
<div style="text-align:center; padding:10px; color:#555; font-size:14px;">
  &copy; <?= date('Y') ?> Sistem Perpustakaan
</div>

</body>
</html>